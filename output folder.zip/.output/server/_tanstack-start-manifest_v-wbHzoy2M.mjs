//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-wbHzoy2M.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/DEEPMIND/Downloads/ts-consoritum-hub-main/ts-consoritum-hub-main/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/about",
			"/auth",
			"/contact",
			"/gallery",
			"/services",
			"/sitemap.xml",
			"/subsidiaries",
			"/team"
		],
		preloads: [
			"/assets/index-DywrtPx7.js",
			"/assets/jsx-runtime-BKllkxft.js",
			"/assets/useStore-CfeScQ2w.js",
			"/assets/matchContext-Cj72w4Bs.js",
			"/assets/useRouter-DQzVw-2q.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DywrtPx7.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/DEEPMIND/Downloads/ts-consoritum-hub-main/ts-consoritum-hub-main/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-Cz_1xjZx.js",
			"/assets/arrow-right-DpnOumO9.js",
			"/assets/arrow-up-right-CFf2ZCby.js",
			"/assets/hero-sahara-cKmruF5u.js"
		]
	},
	"/_authenticated": {
		filePath: "C:/Users/DEEPMIND/Downloads/ts-consoritum-hub-main/ts-consoritum-hub-main/src/routes/_authenticated/route.tsx",
		children: ["/_authenticated/admin"],
		preloads: ["/assets/route-DFYq0VAV.js"]
	},
	"/about": {
		filePath: "C:/Users/DEEPMIND/Downloads/ts-consoritum-hub-main/ts-consoritum-hub-main/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-BIKE9j6I.js",
			"/assets/PageHero-DqTTBF8N.js",
			"/assets/about-office-B-5hsklc.js"
		]
	},
	"/auth": {
		filePath: "C:/Users/DEEPMIND/Downloads/ts-consoritum-hub-main/ts-consoritum-hub-main/src/routes/auth.tsx",
		children: void 0,
		preloads: ["/assets/auth-D6lADvEO.js"]
	},
	"/contact": {
		filePath: "C:/Users/DEEPMIND/Downloads/ts-consoritum-hub-main/ts-consoritum-hub-main/src/routes/contact.tsx",
		children: void 0,
		preloads: ["/assets/contact-DVuyH050.js", "/assets/PageHero-DqTTBF8N.js"]
	},
	"/gallery": {
		filePath: "C:/Users/DEEPMIND/Downloads/ts-consoritum-hub-main/ts-consoritum-hub-main/src/routes/gallery.tsx",
		children: void 0,
		preloads: [
			"/assets/gallery-mQzP9M2G.js",
			"/assets/PageHero-DqTTBF8N.js",
			"/assets/about-office-B-5hsklc.js",
			"/assets/hero-sahara-cKmruF5u.js"
		]
	},
	"/services": {
		filePath: "C:/Users/DEEPMIND/Downloads/ts-consoritum-hub-main/ts-consoritum-hub-main/src/routes/services.tsx",
		children: void 0,
		preloads: [
			"/assets/services-Ca_O0-I6.js",
			"/assets/arrow-up-right-CFf2ZCby.js",
			"/assets/PageHero-DqTTBF8N.js"
		]
	},
	"/subsidiaries": {
		filePath: "C:/Users/DEEPMIND/Downloads/ts-consoritum-hub-main/ts-consoritum-hub-main/src/routes/subsidiaries.tsx",
		children: ["/subsidiaries/$slug", "/subsidiaries/"],
		preloads: ["/assets/subsidiaries-DFYq0VAV.js"]
	},
	"/team": {
		filePath: "C:/Users/DEEPMIND/Downloads/ts-consoritum-hub-main/ts-consoritum-hub-main/src/routes/team.tsx",
		children: void 0,
		preloads: ["/assets/team-B9-rCemV.js", "/assets/PageHero-DqTTBF8N.js"]
	},
	"/_authenticated/admin": {
		filePath: "C:/Users/DEEPMIND/Downloads/ts-consoritum-hub-main/ts-consoritum-hub-main/src/routes/_authenticated/admin/route.tsx",
		children: [
			"/_authenticated/admin/about",
			"/_authenticated/admin/gallery",
			"/_authenticated/admin/services",
			"/_authenticated/admin/team",
			"/_authenticated/admin/"
		],
		preloads: ["/assets/route-BbBg-yQj.js", "/assets/users-_vIdjh2x.js"]
	},
	"/subsidiaries/$slug": {
		filePath: "C:/Users/DEEPMIND/Downloads/ts-consoritum-hub-main/ts-consoritum-hub-main/src/routes/subsidiaries.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/subsidiaries._slug-CS86dLy2.js",
			"/assets/subsidiaries._slug-CkpEpbM3.js",
			"/assets/arrow-right-DpnOumO9.js"
		]
	},
	"/subsidiaries/": {
		filePath: "C:/Users/DEEPMIND/Downloads/ts-consoritum-hub-main/ts-consoritum-hub-main/src/routes/subsidiaries.index.tsx",
		children: void 0,
		preloads: [
			"/assets/subsidiaries.index-BDPLa92S.js",
			"/assets/arrow-up-right-CFf2ZCby.js",
			"/assets/PageHero-DqTTBF8N.js"
		]
	},
	"/_authenticated/admin/about": {
		filePath: "C:/Users/DEEPMIND/Downloads/ts-consoritum-hub-main/ts-consoritum-hub-main/src/routes/_authenticated/admin/about.tsx",
		children: void 0,
		preloads: ["/assets/about-CwXvh2r9.js"]
	},
	"/_authenticated/admin/gallery": {
		filePath: "C:/Users/DEEPMIND/Downloads/ts-consoritum-hub-main/ts-consoritum-hub-main/src/routes/_authenticated/admin/gallery.tsx",
		children: void 0,
		preloads: ["/assets/gallery-Cux5ft8p.js", "/assets/upload-D5vo8wlq.js"]
	},
	"/_authenticated/admin/services": {
		filePath: "C:/Users/DEEPMIND/Downloads/ts-consoritum-hub-main/ts-consoritum-hub-main/src/routes/_authenticated/admin/services.tsx",
		children: void 0,
		preloads: [
			"/assets/services-Cwy4jEPk.js",
			"/assets/ImageUploader-DBUsioSg.js",
			"/assets/upload-D5vo8wlq.js"
		]
	},
	"/_authenticated/admin/team": {
		filePath: "C:/Users/DEEPMIND/Downloads/ts-consoritum-hub-main/ts-consoritum-hub-main/src/routes/_authenticated/admin/team.tsx",
		children: void 0,
		preloads: [
			"/assets/team-BwDidwH4.js",
			"/assets/ImageUploader-DBUsioSg.js",
			"/assets/upload-D5vo8wlq.js"
		]
	},
	"/_authenticated/admin/": {
		filePath: "C:/Users/DEEPMIND/Downloads/ts-consoritum-hub-main/ts-consoritum-hub-main/src/routes/_authenticated/admin/index.tsx",
		children: void 0,
		preloads: ["/assets/admin-DZEoGsN8.js"]
	}
} });
//#endregion
export { tsrStartManifest };
