globalThis.__nitro_main__ = import.meta.url;
import { n as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4f95-3RXc3p2mhEAs1WBwaIvE0Y0uu0Y\"",
		"mtime": "2026-07-24T13:21:34.000Z",
		"size": 20373,
		"path": "../public/favicon.ico"
	},
	"/assets/about-BIKE9j6I.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1637-BX1awB49lK2bPwCMIhC90s01AxQ\"",
		"mtime": "2026-07-26T10:03:08.484Z",
		"size": 5687,
		"path": "../public/assets/about-BIKE9j6I.js"
	},
	"/assets/about-CwXvh2r9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8e5-QzI9SmrNBel9CwdyD5PfkSh7yQE\"",
		"mtime": "2026-07-26T10:03:08.484Z",
		"size": 2277,
		"path": "../public/assets/about-CwXvh2r9.js"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"17-ZZkCVrbr4BSdjt/K43J0tq8+Qq4\"",
		"mtime": "2026-07-24T13:21:34.000Z",
		"size": 23,
		"path": "../public/robots.txt"
	},
	"/assets/about-office-B-5hsklc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"39-fl7VhAkA4CxvN+YKj2SJ2HQst+A\"",
		"mtime": "2026-07-26T10:03:08.485Z",
		"size": 57,
		"path": "../public/assets/about-office-B-5hsklc.js"
	},
	"/assets/admin-DZEoGsN8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"519-4ebJANbMXwfWhijOWFwZK5tYWz0\"",
		"mtime": "2026-07-26T10:03:08.485Z",
		"size": 1305,
		"path": "../public/assets/admin-DZEoGsN8.js"
	},
	"/assets/arrow-right-DpnOumO9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9a-rGESHZo3UAL079QuqUNoyAwuj3o\"",
		"mtime": "2026-07-26T10:03:08.486Z",
		"size": 154,
		"path": "../public/assets/arrow-right-DpnOumO9.js"
	},
	"/assets/arrow-up-right-CFf2ZCby.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9c-2k5RXOf85gxC4W72WNwPW+87RGQ\"",
		"mtime": "2026-07-26T10:03:08.486Z",
		"size": 156,
		"path": "../public/assets/arrow-up-right-CFf2ZCby.js"
	},
	"/assets/contact-DVuyH050.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13ec-dGD9x6VJKQ5QF63Sy3AX3EhfFoQ\"",
		"mtime": "2026-07-26T10:03:08.487Z",
		"size": 5100,
		"path": "../public/assets/contact-DVuyH050.js"
	},
	"/assets/auth-D6lADvEO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"964-kQGuMflCUxusVdQUMFtD31pPUHg\"",
		"mtime": "2026-07-26T10:03:08.487Z",
		"size": 2404,
		"path": "../public/assets/auth-D6lADvEO.js"
	},
	"/assets/gallery-mQzP9M2G.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5c0-mzaOLl5ODtrpLN5kBaXgSYLx2kE\"",
		"mtime": "2026-07-26T10:03:08.488Z",
		"size": 1472,
		"path": "../public/assets/gallery-mQzP9M2G.js"
	},
	"/assets/about-office-BIaATyw8.jpg": {
		"type": "image/jpeg",
		"etag": "\"2b6a6-VZUcEjfTDTaSnqZmK8pbg67YbMY\"",
		"mtime": "2026-07-26T10:03:09.018Z",
		"size": 177830,
		"path": "../public/assets/about-office-BIaATyw8.jpg"
	},
	"/assets/gallery-Cux5ft8p.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e00-pyYKjlz6pZ7escEoxRvHYoVBMZ4\"",
		"mtime": "2026-07-26T10:03:08.488Z",
		"size": 3584,
		"path": "../public/assets/gallery-Cux5ft8p.js"
	},
	"/assets/hero-sahara-cKmruF5u.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"38-4LWuHcfaAiAR7tpBbxOPh8S6AuE\"",
		"mtime": "2026-07-26T10:03:08.489Z",
		"size": 56,
		"path": "../public/assets/hero-sahara-cKmruF5u.js"
	},
	"/assets/ImageUploader-DBUsioSg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"661-ywHtFd3s2E7Fvts+tPUnBcNy5/Y\"",
		"mtime": "2026-07-26T10:03:08.424Z",
		"size": 1633,
		"path": "../public/assets/ImageUploader-DBUsioSg.js"
	},
	"/assets/matchContext-Cj72w4Bs.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"30a-ohDkSaxS7+mfSw6Tj4aT6uoPzSs\"",
		"mtime": "2026-07-26T10:03:08.489Z",
		"size": 778,
		"path": "../public/assets/matchContext-Cj72w4Bs.js"
	},
	"/assets/hero-sahara-BN9hu2WZ.jpg": {
		"type": "image/jpeg",
		"etag": "\"1adea-/6JYOSapjNCItOvjPZytvT1+1Bk\"",
		"mtime": "2026-07-26T10:03:09.019Z",
		"size": 110058,
		"path": "../public/assets/hero-sahara-BN9hu2WZ.jpg"
	},
	"/assets/jsx-runtime-BKllkxft.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"20d8-OsELDERtTmr6S+CCOADMMZjtZ2o\"",
		"mtime": "2026-07-26T10:03:08.489Z",
		"size": 8408,
		"path": "../public/assets/jsx-runtime-BKllkxft.js"
	},
	"/assets/PageHero-DqTTBF8N.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"417-VTqKGtkfXVSDPhueYS18/lxg4UA\"",
		"mtime": "2026-07-26T10:03:08.483Z",
		"size": 1047,
		"path": "../public/assets/PageHero-DqTTBF8N.js"
	},
	"/assets/route-BbBg-yQj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b8e-cyeoVFpv3swF7WIpsbn4F6dUcY4\"",
		"mtime": "2026-07-26T10:03:08.490Z",
		"size": 2958,
		"path": "../public/assets/route-BbBg-yQj.js"
	},
	"/assets/routes-Cz_1xjZx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"213e-P+ypjVcKdA/LPyj74GQZsZuU8tg\"",
		"mtime": "2026-07-26T10:03:08.775Z",
		"size": 8510,
		"path": "../public/assets/routes-Cz_1xjZx.js"
	},
	"/assets/route-DFYq0VAV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8d-JZmRyoANlDVpmRvF1Ee89igxoFI\"",
		"mtime": "2026-07-26T10:03:08.774Z",
		"size": 141,
		"path": "../public/assets/route-DFYq0VAV.js"
	},
	"/assets/services-Ca_O0-I6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7ee-zmD9zaAANjLZSvwAg2FxgVRaULU\"",
		"mtime": "2026-07-26T10:03:08.776Z",
		"size": 2030,
		"path": "../public/assets/services-Ca_O0-I6.js"
	},
	"/assets/services-Cwy4jEPk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11ac-LR922h3r3EMH2Ho6hn3YCV03pmw\"",
		"mtime": "2026-07-26T10:03:08.776Z",
		"size": 4524,
		"path": "../public/assets/services-Cwy4jEPk.js"
	},
	"/assets/index-DywrtPx7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8795b-gx3E41TjJ7KCQGfud8j+fJhdqhw\"",
		"mtime": "2026-07-26T10:03:08.424Z",
		"size": 555355,
		"path": "../public/assets/index-DywrtPx7.js"
	},
	"/assets/styles-C1YHboO2.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"16d7a-Fpm6mZ05ucVVIeAO+qklyEQ8SyM\"",
		"mtime": "2026-07-26T10:03:09.021Z",
		"size": 93562,
		"path": "../public/assets/styles-C1YHboO2.css"
	},
	"/assets/subsidiaries-DFYq0VAV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8d-JZmRyoANlDVpmRvF1Ee89igxoFI\"",
		"mtime": "2026-07-26T10:03:08.776Z",
		"size": 141,
		"path": "../public/assets/subsidiaries-DFYq0VAV.js"
	},
	"/assets/subsidiaries.index-BDPLa92S.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6fa-+knMuTBWnPNhgds7COF9yNPzKcY\"",
		"mtime": "2026-07-26T10:03:08.778Z",
		"size": 1786,
		"path": "../public/assets/subsidiaries.index-BDPLa92S.js"
	},
	"/assets/subsidiaries._slug-CkpEpbM3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d5f-vNppx9+8SEdF4bsI/jSv2I7qebk\"",
		"mtime": "2026-07-26T10:03:08.777Z",
		"size": 3423,
		"path": "../public/assets/subsidiaries._slug-CkpEpbM3.js"
	},
	"/assets/subsidiaries._slug-CS86dLy2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"18e-THboYcQrou9Xt5RIuDCZ9Q7/K3Y\"",
		"mtime": "2026-07-26T10:03:08.777Z",
		"size": 398,
		"path": "../public/assets/subsidiaries._slug-CS86dLy2.js"
	},
	"/assets/svc-agri-DkqJtSmy.jpg": {
		"type": "image/jpeg",
		"etag": "\"393c4-If9IE2FiPNSJrdCcv5sKGLA+4Hc\"",
		"mtime": "2026-07-26T10:03:09.022Z",
		"size": 234436,
		"path": "../public/assets/svc-agri-DkqJtSmy.jpg"
	},
	"/assets/svc-logistics-CQ_6bjpa.jpg": {
		"type": "image/jpeg",
		"etag": "\"2d450-qvsZumrmGeSGPup1H2Dy32hy3Rw\"",
		"mtime": "2026-07-26T10:03:09.023Z",
		"size": 185424,
		"path": "../public/assets/svc-logistics-CQ_6bjpa.jpg"
	},
	"/assets/svc-oilgas-D9NR3aWD.jpg": {
		"type": "image/jpeg",
		"etag": "\"175be-G+dGPWA3Thqa5+iVNL3z/C9+ZPE\"",
		"mtime": "2026-07-26T10:03:09.701Z",
		"size": 95678,
		"path": "../public/assets/svc-oilgas-D9NR3aWD.jpg"
	},
	"/assets/svc-mining-DW8rHH6E.jpg": {
		"type": "image/jpeg",
		"etag": "\"3861d-wAac9uPxF2rpJATc33RQLUeqS98\"",
		"mtime": "2026-07-26T10:03:09.024Z",
		"size": 230941,
		"path": "../public/assets/svc-mining-DW8rHH6E.jpg"
	},
	"/assets/svc-pipeline-B83IT7Sd.jpg": {
		"type": "image/jpeg",
		"etag": "\"2a894-+4vOG4deRan1oCKpsjShzNRRfUU\"",
		"mtime": "2026-07-26T10:03:09.704Z",
		"size": 174228,
		"path": "../public/assets/svc-pipeline-B83IT7Sd.jpg"
	},
	"/assets/team-B9-rCemV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c55-alUnxdMhpNfwRBKkiTrQvEMs1YQ\"",
		"mtime": "2026-07-26T10:03:08.778Z",
		"size": 3157,
		"path": "../public/assets/team-B9-rCemV.js"
	},
	"/assets/upload-D5vo8wlq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ee-+L5nJTJ7cpvGPeIe04yxAq2ul84\"",
		"mtime": "2026-07-26T10:03:09.012Z",
		"size": 494,
		"path": "../public/assets/upload-D5vo8wlq.js"
	},
	"/assets/svc-power-Di1O1SvH.jpg": {
		"type": "image/jpeg",
		"etag": "\"19038-SLqI5RKcxTLv00shhLUwufFOY3I\"",
		"mtime": "2026-07-26T10:03:09.705Z",
		"size": 102456,
		"path": "../public/assets/svc-power-Di1O1SvH.jpg"
	},
	"/assets/useRouter-DQzVw-2q.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"97-Kqlf0YLe9hHIesaV05RETSxmlWI\"",
		"mtime": "2026-07-26T10:03:09.013Z",
		"size": 151,
		"path": "../public/assets/useRouter-DQzVw-2q.js"
	},
	"/assets/team-BwDidwH4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c77-24PKjOcHVv8Rdks520N0U66E0ng\"",
		"mtime": "2026-07-26T10:03:09.009Z",
		"size": 3191,
		"path": "../public/assets/team-BwDidwH4.js"
	},
	"/assets/users-_vIdjh2x.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3e8-ldOPrHnwlqk8sri9jR61to47VG8\"",
		"mtime": "2026-07-26T10:03:09.016Z",
		"size": 1e3,
		"path": "../public/assets/users-_vIdjh2x.js"
	},
	"/assets/useStore-CfeScQ2w.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4a98-/9XdtTCwQ8eNbKktVQ2vHnWrrMk\"",
		"mtime": "2026-07-26T10:03:09.015Z",
		"size": 19096,
		"path": "../public/assets/useStore-CfeScQ2w.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_NjOdLa = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_NjOdLa
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
