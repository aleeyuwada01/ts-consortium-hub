import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { i as useSubsidiaries } from "./content-hooks-BW9Qg46z.mjs";
import { t as PageHero } from "./PageHero-BTcU8EON.mjs";
import { A as ArrowUpRight } from "../_libs/lucide-react.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/services-Cfz2HmEF.js
var import_jsx_runtime = require_jsx_runtime();
function Services() {
	const { data: SUBSIDIARIES = [] } = useSubsidiaries();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
		eyebrow: "Our Services",
		title: "Integrated capability. Sector-specialist delivery.",
		subtitle: "Six specialist subsidiaries. One accountable partner. From feasibility to commissioning to long-term operations — we cover the full industrial project lifecycle."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "section-pad",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "container-page space-y-6",
			children: SUBSIDIARIES.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/subsidiaries/$slug",
				params: { slug: s.slug },
				className: "group grid gap-8 md:grid-cols-12 items-center rounded-3xl bg-card border border-border p-6 md:p-8 hover:border-brand-green/50 hover:-translate-y-0.5 transition-all",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-4 relative overflow-hidden rounded-2xl aspect-[4/3]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: s.image,
						alt: s.name,
						width: 1200,
						height: 800,
						loading: "lazy",
						className: "h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "absolute top-3 left-3 text-xs font-mono bg-white/85 text-brand-ink px-2 py-1 rounded",
						children: ["0", i + 1]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-2xl md:text-3xl font-bold",
								children: s.short
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "h-6 w-6 text-muted-foreground transition-transform group-hover:rotate-45 group-hover:text-brand-green-deep" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-muted-foreground leading-relaxed",
							children: s.description
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-5 flex flex-wrap gap-2",
							children: s.capabilities.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "text-xs px-3 py-1.5 rounded-full bg-secondary text-secondary-foreground font-medium",
								children: c
							}, c))
						})
					]
				})]
			}, s.slug))
		})
	})] });
}
//#endregion
export { Services as component };
