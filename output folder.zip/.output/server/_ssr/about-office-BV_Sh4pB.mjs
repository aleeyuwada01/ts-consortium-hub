//#region node_modules/.nitro/vite/services/ssr/assets/about-office-BV_Sh4pB.js
var about_office_default = "/assets/about-office-BIaATyw8.jpg";
//#endregion
export { about_office_default as t };
