//#region node_modules/.nitro/vite/services/ssr/assets/hero-sahara-CwOp8IFE.js
var hero_sahara_default = "/assets/hero-sahara-BN9hu2WZ.jpg";
//#endregion
export { hero_sahara_default as t };
