import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { i as useSubsidiaries } from "./content-hooks-BW9Qg46z.mjs";
import { A as ArrowUpRight, C as GitBranch, T as Droplet, j as ArrowRight, o as Truck, p as Mountain, r as Wheat, t as Zap } from "../_libs/lucide-react.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as hero_sahara_default } from "./hero-sahara-CwOp8IFE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BjWesdoM.js
var import_jsx_runtime = require_jsx_runtime();
var ICONS = {
	"power-infrastructure": Zap,
	"oil-and-gas": Droplet,
	"agriculture": Wheat,
	"pipeline-infrastructure": GitBranch,
	"logistics-services": Truck,
	"mining-and-exploration": Mountain
};
function Home() {
	const { data: SUBSIDIARIES = [] } = useSubsidiaries();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative min-h-[92vh] flex items-center overflow-hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: hero_sahara_default,
					alt: "Sahara landscape with industrial infrastructure at sunset",
					className: "absolute inset-0 h-full w-full object-cover",
					width: 1920,
					height: 1080
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-r from-black/85 via-black/60 to-black/20" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "container-page relative py-24 text-white",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "eyebrow text-brand-green",
							children: "Trans Sahara Consortium Ltd"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "mt-5 text-5xl md:text-7xl lg:text-8xl font-bold max-w-4xl leading-[0.98]",
							children: [
								"Building Africa's ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-brand-green",
									children: "industrial"
								}),
								" backbone."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-8 text-lg md:text-xl text-white/75 max-w-2xl leading-relaxed",
							children: "From the power grids and pipelines that energize a continent, to the farms, fleets and mines that feed and fuel it — we deliver integrated solutions at Sahara-scale."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-10 flex flex-wrap gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/subsidiaries",
								className: "btn-primary",
								children: ["Explore Our Subsidiaries ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/contact",
								className: "btn-outline text-white",
								children: "Partner with us"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-20 grid grid-cols-2 md:grid-cols-4 gap-8 max-w-3xl",
							children: [
								["6", "Subsidiaries"],
								["15+", "Years of expertise"],
								["100+", "Projects delivered"],
								["1", "Trusted partner"]
							].map(([n, l]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-4xl md:text-5xl font-bold text-brand-green",
								children: n
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 text-xs uppercase tracking-widest text-white/60",
								children: l
							})] }, l))
						})
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "section-pad",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-page grid gap-12 lg:grid-cols-12 items-start",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "eyebrow",
						children: "Who we are"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "mt-4 text-3xl md:text-5xl font-bold leading-tight",
						children: [
							"One consortium.",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							" Six industries.",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							" Endless capability."
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-7 space-y-6 text-lg text-muted-foreground leading-relaxed",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Trans Sahara Consortium Limited is a Nigerian-headquartered industrial group operating six specialized subsidiaries across the sectors that matter most to Africa's future — energy, agriculture, infrastructure, logistics and natural resources." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "We combine the agility of a project-focused business with the balance sheet and technical depth of a diversified conglomerate — delivering to international standards, on Sahara timelines." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/about",
							className: "inline-flex items-center gap-2 text-brand-green-deep font-semibold hover:gap-3 transition-all",
							children: ["About Trans Sahara Consortium ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
						})
					]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "section-pad bg-secondary/40",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-page",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-end justify-between gap-6 mb-14",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "eyebrow",
						children: "Our subsidiaries"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 text-3xl md:text-5xl font-bold max-w-2xl",
						children: "Six businesses. One shared standard of excellence."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/subsidiaries",
						className: "btn-outline text-foreground",
						children: ["View all ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-5 md:grid-cols-2 lg:grid-cols-3",
					children: SUBSIDIARIES.map((s, i) => {
						const Icon = ICONS[s.slug] ?? Zap;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/subsidiaries/$slug",
							params: { slug: s.slug },
							className: "group relative overflow-hidden rounded-3xl bg-card border border-border hover:border-brand-green/50 transition-all hover:-translate-y-1 hover:shadow-2xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "aspect-[4/3] overflow-hidden",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: s.image,
										alt: s.name,
										loading: "lazy",
										width: 1200,
										height: 800,
										className: "h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-x-0 top-0 aspect-[4/3] bg-gradient-to-t from-black/70 via-transparent to-transparent" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "absolute top-5 left-5 flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs font-mono text-white/70",
										children: ["0", i + 1]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-9 w-9 rounded-full bg-white/15 backdrop-blur flex items-center justify-center",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4 text-white" })
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "absolute top-5 right-5 h-6 w-6 text-white/80 transition-transform group-hover:rotate-45" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-xl font-bold",
										children: s.short
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm text-muted-foreground line-clamp-2",
										children: s.tagline
									})]
								})
							]
						}, s.slug);
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "section-pad",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "container-page",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative overflow-hidden rounded-[2rem] ink-gradient p-10 md:p-16 text-white",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -top-24 -right-24 h-80 w-80 rounded-full bg-brand-green/25 blur-3xl" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -bottom-24 -left-24 h-80 w-80 rounded-full bg-brand-red/20 blur-3xl" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative grid gap-8 md:grid-cols-2 items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "eyebrow text-brand-green",
									children: "Let's build together"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-4 text-3xl md:text-5xl font-bold leading-tight",
									children: "Have a project at continental scale?"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-white/70 max-w-md",
									children: "Whether you're a government, investor or industrial partner — we'd like to hear from you."
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex md:justify-end",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/contact",
									className: "btn-primary",
									children: ["Start a conversation ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
								})
							})]
						})
					]
				})
			})
		})
	] });
}
//#endregion
export { Home as component };
