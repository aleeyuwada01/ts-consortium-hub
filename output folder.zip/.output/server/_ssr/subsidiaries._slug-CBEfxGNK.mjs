import { r as SUBSIDIARIES } from "./site-data-e6ezcBhU.mjs";
import { N as notFound, m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/subsidiaries._slug-CBEfxGNK.js
var $$splitNotFoundComponentImporter = () => import("./subsidiaries._slug-DbOuLodA.mjs");
var $$splitComponentImporter = () => import("./subsidiaries._slug-Ba0tw55B.mjs");
var Route = createFileRoute("/subsidiaries/$slug")({
	loader: ({ params }) => {
		const item = SUBSIDIARIES.find((s) => s.slug === params.slug);
		if (!item) throw notFound();
		return { item };
	},
	head: ({ loaderData }) => {
		if (!loaderData) return { meta: [{ title: "Subsidiary not found" }, {
			name: "robots",
			content: "noindex"
		}] };
		const s = loaderData.item;
		return {
			meta: [
				{ title: `${s.name} — Trans Sahara Consortium` },
				{
					name: "description",
					content: s.description
				},
				{
					property: "og:title",
					content: s.name
				},
				{
					property: "og:description",
					content: s.tagline
				},
				{
					property: "og:url",
					content: `/subsidiaries/${s.slug}`
				},
				{
					property: "og:type",
					content: "article"
				}
			],
			links: [{
				rel: "canonical",
				href: `/subsidiaries/${s.slug}`
			}]
		};
	},
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent")
});
//#endregion
export { Route as t };
