import { n as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-CqoHPUyh.mjs";
import { a as require_react, i as require_jsx_runtime, r as useQueryClient } from "../_libs/react+tanstack__react-query.mjs";
import { r as useGallery, t as uploadSiteImage } from "./content-hooks-BW9Qg46z.mjs";
import { a as Upload, s as Trash2 } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/gallery-CSl2VUrX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function GalleryAdmin() {
	const { data = [], isLoading } = useGallery();
	const qc = useQueryClient();
	const refresh = () => qc.invalidateQueries({ queryKey: ["gallery_images"] });
	const [uploading, setUploading] = (0, import_react.useState)(false);
	const [title, setTitle] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("");
	async function onUpload(e) {
		const files = Array.from(e.target.files ?? []);
		if (!files.length) return;
		setUploading(true);
		try {
			let order = data.length ? Math.max(...data.map((g) => g.sort_order)) + 1 : 1;
			for (const file of files) {
				const url = await uploadSiteImage(file, "gallery");
				const { error } = await supabase.from("gallery_images").insert({
					title: title || file.name.replace(/\.[^.]+$/, ""),
					category: category || null,
					image_url: url,
					sort_order: order++
				});
				if (error) throw error;
			}
			setTitle("");
			setCategory("");
			refresh();
		} catch (err) {
			alert(err instanceof Error ? err.message : "Upload failed");
		} finally {
			setUploading(false);
			e.target.value = "";
		}
	}
	async function remove(g) {
		if (!confirm(`Delete "${g.title}"?`)) return;
		const { error } = await supabase.from("gallery_images").delete().eq("id", g.id);
		if (error) alert(error.message);
		refresh();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-bold",
				children: "Gallery"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Photos on the public /gallery page."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-border bg-card p-5 space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: title,
						onChange: (e) => setTitle(e.target.value),
						placeholder: "Title (optional, defaults to filename)",
						className: "rounded-lg border border-input bg-background px-3 py-2 text-sm"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: category,
						onChange: (e) => setCategory(e.target.value),
						placeholder: "Category (optional)",
						className: "rounded-lg border border-input bg-background px-3 py-2 text-sm"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "btn-primary inline-flex cursor-pointer",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "h-4 w-4" }),
						" ",
						uploading ? "Uploading…" : "Upload images",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: "image/*",
							multiple: true,
							className: "hidden",
							onChange: onUpload,
							disabled: uploading
						})
					]
				})]
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted-foreground",
				children: "Loading…"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
				children: data.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GalleryCard, {
					img: g,
					onDelete: () => remove(g),
					onChanged: refresh
				}, g.id))
			})
		]
	});
}
function GalleryCard({ img, onDelete, onChanged }) {
	const [g, setG] = (0, import_react.useState)(img);
	async function save() {
		const { error } = await supabase.from("gallery_images").update({
			title: g.title,
			category: g.category,
			sort_order: g.sort_order
		}).eq("id", g.id);
		if (error) alert(error.message);
		onChanged();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-border bg-card overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: g.image_url,
			alt: g.title,
			className: "aspect-[4/3] w-full object-cover"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "p-3 space-y-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: g.title,
					onChange: (e) => setG({
						...g,
						title: e.target.value
					}),
					className: "w-full rounded-lg border border-input bg-background px-2 py-1.5 text-sm"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: g.category ?? "",
					onChange: (e) => setG({
						...g,
						category: e.target.value || null
					}),
					placeholder: "Category",
					className: "w-full rounded-lg border border-input bg-background px-2 py-1.5 text-sm"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "number",
					value: g.sort_order,
					onChange: (e) => setG({
						...g,
						sort_order: Number(e.target.value)
					}),
					className: "w-full rounded-lg border border-input bg-background px-2 py-1.5 text-sm"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: save,
						className: "btn-primary text-xs flex-1 justify-center",
						children: "Save"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: onDelete,
						className: "btn-outline text-xs text-brand-red",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-3.5 w-3.5" })
					})]
				})
			]
		})]
	});
}
//#endregion
export { GalleryAdmin as component };
