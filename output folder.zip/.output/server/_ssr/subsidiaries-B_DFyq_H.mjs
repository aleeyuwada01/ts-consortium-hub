import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { f as Outlet } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/subsidiaries-B_DFyq_H.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {});
//#endregion
export { SplitComponent as component };
