import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { i as useSubsidiaries } from "./content-hooks-BW9Qg46z.mjs";
import { t as PageHero } from "./PageHero-BTcU8EON.mjs";
import { A as ArrowUpRight } from "../_libs/lucide-react.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/subsidiaries.index-Crp1dAFf.js
var import_jsx_runtime = require_jsx_runtime();
function List() {
	const { data: SUBSIDIARIES = [] } = useSubsidiaries();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
		eyebrow: "Subsidiaries",
		title: "Six businesses that form the Trans Sahara Consortium.",
		subtitle: "Each subsidiary operates as a sector specialist — sharing the technical, financial and governance resources of the wider group."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "section-pad",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "container-page grid gap-6 md:grid-cols-2",
			children: SUBSIDIARIES.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/subsidiaries/$slug",
				params: { slug: s.slug },
				className: "group relative overflow-hidden rounded-3xl border border-border hover:border-brand-green/50 transition-all hover:-translate-y-1 hover:shadow-2xl bg-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "aspect-[16/10] overflow-hidden",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: s.image,
							alt: s.name,
							width: 1200,
							height: 800,
							loading: "lazy",
							className: "h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-x-0 top-0 aspect-[16/10] bg-gradient-to-t from-black/80 via-black/10 to-transparent" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "absolute top-5 left-5 text-xs font-mono text-white/80",
						children: [
							"0",
							i + 1,
							" / 06"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "absolute top-5 right-5 h-6 w-6 text-white/90 transition-transform group-hover:rotate-45" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute bottom-0 inset-x-0 p-6 md:p-8 text-white",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-2xl md:text-3xl font-bold",
							children: s.short
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-white/80 max-w-md",
							children: s.tagline
						})]
					})
				]
			}, s.slug))
		})
	})] });
}
//#endregion
export { List as component };
