import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { a as useTeam } from "./content-hooks-BW9Qg46z.mjs";
import { t as PageHero } from "./PageHero-BTcU8EON.mjs";
import { g as Mail, v as Linkedin } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/team-X7XSEyuh.js
var import_jsx_runtime = require_jsx_runtime();
var ACCENTS = [
	"from-brand-green to-brand-green-deep",
	"from-brand-red to-brand-green-deep",
	"from-brand-green-deep to-brand-ink",
	"from-brand-ink to-brand-green",
	"from-brand-green to-brand-ink",
	"from-brand-red to-brand-ink",
	"from-brand-green to-brand-red",
	"from-brand-ink to-brand-green-deep",
	"from-brand-green-deep to-brand-red",
	"from-brand-ink to-brand-red"
];
function initials(name) {
	return name.split(/\s+/).map((w) => w[0]).filter(Boolean).slice(0, 2).join("").toUpperCase();
}
function Team() {
	const { data = [] } = useTeam();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
		eyebrow: "Our Team",
		title: "The leadership behind the consortium.",
		subtitle: "A multidisciplinary executive team combining decades of African industrial experience with international engineering, finance and governance expertise."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "section-pad",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-page",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4",
				children: data.map((m, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "group rounded-3xl bg-card border border-border overflow-hidden hover:border-brand-green/50 transition-all hover:-translate-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `aspect-[4/5] bg-gradient-to-br ${ACCENTS[i % ACCENTS.length]} relative flex items-end justify-center p-6 overflow-hidden`,
						children: [m.image_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: m.image_url,
							alt: m.name,
							className: "absolute inset-0 h-full w-full object-cover"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-6xl font-bold text-white/20",
							children: initials(m.name)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative flex gap-2",
							children: [m.linkedin_url && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: m.linkedin_url,
								target: "_blank",
								rel: "noopener noreferrer",
								"aria-label": "LinkedIn",
								className: "h-9 w-9 rounded-full bg-white/15 backdrop-blur flex items-center justify-center text-white hover:bg-white hover:text-brand-ink transition-colors",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Linkedin, { className: "h-4 w-4" })
							}), m.email && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `mailto:${m.email}`,
								"aria-label": "Email",
								className: "h-9 w-9 rounded-full bg-white/15 backdrop-blur flex items-center justify-center text-white hover:bg-white hover:text-brand-ink transition-colors",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-4 w-4" })
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-bold",
							children: m.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground mt-1",
							children: m.role
						})]
					})]
				}, m.id))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-14 text-sm text-muted-foreground max-w-2xl",
				children: [
					"Full biographies and named appointments are available on request. Please",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "mailto:info@tsconsortium.ng",
						className: "text-brand-green-deep font-semibold underline underline-offset-4",
						children: "contact our corporate office"
					}),
					"."
				]
			})]
		})
	})] });
}
//#endregion
export { Team as component };
