import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as useAbout } from "./content-hooks-BW9Qg46z.mjs";
import { t as PageHero } from "./PageHero-BTcU8EON.mjs";
import { t as about_office_default } from "./about-office-BV_Sh4pB.mjs";
import { E as Compass, c as Target, l as ShieldCheck, x as HeartHandshake } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-Dk88hlLV.js
var import_jsx_runtime = require_jsx_runtime();
var values = [
	{
		icon: Target,
		title: "Purpose-built",
		body: "Every project starts with the outcome — measurable value for our clients and the communities we operate in."
	},
	{
		icon: ShieldCheck,
		title: "Uncompromising HSE",
		body: "Zero-harm operations governed by international HSE standards across every subsidiary."
	},
	{
		icon: Compass,
		title: "African expertise",
		body: "Deep local knowledge combined with global engineering capability — a rare and hard-won advantage."
	},
	{
		icon: HeartHandshake,
		title: "Long-term partnership",
		body: "We build businesses and relationships that outlast the individual project."
	}
];
var DEFAULTS = {
	hero_eyebrow: "About Us",
	hero_title: "A Nigerian industrial group with a Sahara-wide vision.",
	hero_subtitle: "Trans Sahara Consortium Limited was founded to bring together the specialized capability required to deliver Africa's most demanding infrastructure and industrial projects — under one accountable roof.",
	story_heading: "Built for the industries that build nations.",
	story_body: "Headquartered on the 8th Floor of the Bank of Industry Tower in Abuja, Trans Sahara Consortium operates as an integrated industrial platform — bringing engineering, capital, logistics and local expertise to bear on projects that move Africa forward. Our six subsidiaries operate independently in their sectors, yet share a common commitment to technical excellence, transparent governance and long-term community value.",
	mission: "To deliver world-class industrial and infrastructure solutions that unlock prosperity across Africa — safely, sustainably and profitably.",
	vision: "To be the most trusted African industrial consortium — the partner of choice for governments, investors and communities from the Sahara to the sea."
};
function About() {
	const { data } = useAbout();
	const c = data ?? DEFAULTS;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			eyebrow: c.hero_eyebrow,
			title: c.hero_title,
			subtitle: c.hero_subtitle
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "section-pad",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-page grid gap-16 lg:grid-cols-2 items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: about_office_default,
						alt: "Trans Sahara Consortium headquarters in Abuja",
						width: 1600,
						height: 1e3,
						loading: "lazy",
						className: "rounded-3xl w-full h-auto shadow-2xl"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute -bottom-8 -right-4 md:-right-8 bg-card border border-border rounded-2xl p-6 shadow-xl max-w-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-4xl font-bold text-brand-green-deep",
							children: "6"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm text-muted-foreground mt-1",
							children: "Specialized subsidiaries operating under one consortium"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "eyebrow",
						children: "Our story"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 text-3xl md:text-4xl font-bold",
						children: c.story_heading
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 space-y-5 text-muted-foreground text-lg leading-relaxed whitespace-pre-line",
						children: c.story_body
					})
				] })]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "section-pad bg-secondary/40",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-page",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-2xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "eyebrow",
						children: "What we stand for"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 text-3xl md:text-5xl font-bold",
						children: "Values that scale across every subsidiary."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-4",
					children: values.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl bg-card border border-border p-8 hover:border-brand-green/50 transition-colors",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-12 w-12 rounded-xl bg-brand-green/10 flex items-center justify-center text-brand-green-deep",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(v.icon, { className: "h-6 w-6" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-5 text-lg font-bold",
								children: v.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground leading-relaxed",
								children: v.body
							})
						]
					}, v.title))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "section-pad",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-page grid gap-10 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-3xl ink-gradient text-white p-10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "eyebrow text-brand-green",
						children: "Mission"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-2xl md:text-3xl font-semibold leading-snug",
						children: c.mission
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-3xl bg-card border border-border p-10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "eyebrow",
						children: "Vision"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-2xl md:text-3xl font-semibold leading-snug",
						children: c.vision
					})]
				})]
			})
		})
	] });
}
//#endregion
export { About as component };
