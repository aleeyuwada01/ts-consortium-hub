import { n as __toESM } from "../_runtime.mjs";
import { n as NAV_LINKS, r as SUBSIDIARIES, t as CONTACT } from "./site-data-e6ezcBhU.mjs";
import { t as supabase } from "./client-CqoHPUyh.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { a as require_react, i as require_jsx_runtime, n as QueryClientProvider } from "../_libs/react+tanstack__react-query.mjs";
import { i as useSubsidiaries } from "./content-hooks-BW9Qg46z.mjs";
import { O as ChevronDown, S as Globe, f as Phone, g as Mail, h as MapPin, m as Menu, n as X } from "../_libs/lucide-react.mjs";
import { A as redirect, c as HeadContent, d as createRouter, f as Outlet, g as Link, h as createRootRouteWithContext, l as useRouterState, m as createFileRoute, p as lazyRouteComponent, s as Scripts, v as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Route$18 } from "./subsidiaries._slug-CBEfxGNK.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-D1dQICeo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-C1YHboO2.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	window.__lovableReportRuntimeError?.({
		message,
		stack: error instanceof Error ? error.stack : void 0,
		filename: window.location.pathname
	});
}
var tsc_logo_jpg_asset_default = {
	version: 1,
	asset_id: "c987ca29-949f-4cd8-839e-d201cf3cd29d",
	project_id: "0df7f0b6-be7b-4f46-b74b-8c16b209ae57",
	url: "/__l5e/assets-v1/c987ca29-949f-4cd8-839e-d201cf3cd29d/tsc-logo.jpg",
	r2_key: "a/v1/0df7f0b6-be7b-4f46-b74b-8c16b209ae57/c987ca29-949f-4cd8-839e-d201cf3cd29d/tsc-logo.jpg",
	original_filename: "tsc-logo.jpg",
	size: 12431,
	content_type: "image/jpeg",
	created_at: "2026-07-24T20:57:33Z"
};
function SiteHeader() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [scrolled, setScrolled] = (0, import_react.useState)(false);
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const { data: SUBSIDIARIES = [] } = useSubsidiaries();
	(0, import_react.useEffect)(() => {
		const onScroll = () => setScrolled(window.scrollY > 12);
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	(0, import_react.useEffect)(() => {
		setOpen(false);
	}, [pathname]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: `sticky top-0 z-50 transition-all duration-300 ${scrolled ? "bg-background/85 backdrop-blur-xl border-b border-border/60 shadow-sm" : "bg-background/40 backdrop-blur-md"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-page flex items-center justify-between h-20",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "flex items-center gap-3 group",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: tsc_logo_jpg_asset_default.url,
						alt: "Trans Sahara Consortium",
						className: "h-12 w-auto",
						width: 96,
						height: 48
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hidden sm:flex flex-col leading-tight",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[13px] font-bold tracking-widest text-foreground",
							children: "TRANS SAHARA"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] font-semibold tracking-[0.3em] text-brand-green-deep",
							children: "CONSORTIUM"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "hidden lg:flex items-center gap-1",
					children: NAV_LINKS.map((link) => {
						const active = pathname === link.to || link.to !== "/" && pathname.startsWith(link.to);
						if (link.dropdown) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative group",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: link.to,
								className: `flex items-center gap-1 px-4 py-2 rounded-full text-sm font-medium transition-colors ${active ? "text-brand-green-deep" : "text-foreground/80 hover:text-foreground"}`,
								children: [link.label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-3.5 w-3.5 transition-transform group-hover:rotate-180" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "invisible opacity-0 group-hover:visible group-hover:opacity-100 transition-all absolute left-1/2 -translate-x-1/2 top-full pt-3 w-[320px]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "bg-popover border border-border rounded-2xl shadow-2xl p-2 overflow-hidden",
									children: SUBSIDIARIES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/subsidiaries/$slug",
										params: { slug: s.slug },
										className: "flex flex-col gap-0.5 px-4 py-3 rounded-xl hover:bg-secondary transition-colors",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sm font-semibold",
											children: s.short
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-muted-foreground line-clamp-1",
											children: s.tagline
										})]
									}, s.slug))
								})
							})]
						}, link.to);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: link.to,
							className: `px-4 py-2 rounded-full text-sm font-medium transition-colors ${active ? "text-brand-green-deep" : "text-foreground/80 hover:text-foreground"}`,
							children: link.label
						}, link.to);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "hidden lg:block",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/contact",
						className: "btn-primary",
						children: "Get in touch"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setOpen((v) => !v),
					className: "lg:hidden p-2 rounded-md hover:bg-secondary",
					"aria-label": "Toggle menu",
					children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "h-5 w-5" })
				})
			]
		}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "lg:hidden border-t border-border bg-background",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-page py-4 flex flex-col gap-1",
				children: [
					NAV_LINKS.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: link.to,
						className: "px-3 py-3 rounded-lg text-sm font-medium hover:bg-secondary",
						children: link.label
					}, link.to)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pl-4 border-l-2 border-brand-green ml-3 mt-1 flex flex-col",
						children: SUBSIDIARIES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/subsidiaries/$slug",
							params: { slug: s.slug },
							className: "px-3 py-2 text-xs text-muted-foreground hover:text-foreground",
							children: s.short
						}, s.slug))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/contact",
						className: "btn-primary mt-3",
						children: "Get in touch"
					})
				]
			})
		})]
	});
}
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "ink-gradient text-white/85 mt-24",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-page py-16 grid gap-12 md:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 mb-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: tsc_logo_jpg_asset_default.url,
							alt: "TSC",
							className: "h-14 w-auto bg-white rounded-lg p-1",
							width: 112,
							height: 56
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "leading-tight",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-bold tracking-widest",
								children: "TRANS SAHARA"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] font-semibold tracking-[0.3em] text-brand-green",
								children: "CONSORTIUM LTD"
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-white/60 max-w-md leading-relaxed",
						children: "A diversified African industrial group delivering integrated solutions across power, energy, agriculture, logistics and mining — from Abuja to the wider Sahara."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
					className: "text-xs font-bold tracking-[0.2em] text-brand-green mb-4",
					children: "SUBSIDIARIES"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2 text-sm",
					children: SUBSIDIARIES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/subsidiaries/$slug",
						params: { slug: s.slug },
						className: "text-white/70 hover:text-white transition-colors",
						children: s.short
					}) }, s.slug))
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
					className: "text-xs font-bold tracking-[0.2em] text-brand-green mb-4",
					children: "GET IN TOUCH"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "space-y-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3 text-white/70",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-4 w-4 mt-0.5 shrink-0 text-brand-red" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: CONTACT.address })]
						}),
						CONTACT.phones.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3 text-white/70",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "h-4 w-4 mt-0.5 shrink-0 text-brand-red" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `tel:${p.replace(/\s/g, "")}`,
								className: "hover:text-white",
								children: p
							})]
						}, p)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3 text-white/70",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-4 w-4 mt-0.5 shrink-0 text-brand-red" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `mailto:${CONTACT.email}`,
								className: "hover:text-white",
								children: CONTACT.email
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3 text-white/70",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "h-4 w-4 mt-0.5 shrink-0 text-brand-red" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: CONTACT.website })]
						})
					]
				})] })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-white/10",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-page py-6 flex flex-col md:flex-row justify-between gap-2 text-xs text-white/50",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					"© ",
					(/* @__PURE__ */ new Date()).getFullYear(),
					" Trans Sahara Consortium Limited. All rights reserved."
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "RC — Abuja, Nigeria" })]
			})
		})]
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$17 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Trans Sahara Consortium — Power, Energy, Infrastructure" },
			{
				name: "description",
				content: "Trans Sahara Consortium Limited: a diversified African industrial group operating across power, oil & gas, agriculture, pipelines, logistics and mining."
			},
			{
				name: "author",
				content: "Trans Sahara Consortium Limited"
			},
			{
				property: "og:title",
				content: "Trans Sahara Consortium Limited"
			},
			{
				property: "og:description",
				content: "Integrated solutions across power, oil & gas, agriculture, pipelines, logistics and mining — headquartered in Abuja, Nigeria."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				property: "og:site_name",
				content: "Trans Sahara Consortium"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				href: "/favicon.ico",
				type: "image/x-icon"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$17.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-h-screen flex-col",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "flex-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
			]
		})
	});
}
var $$splitComponentImporter$15 = () => import("./routes-BjWesdoM.mjs");
var Route$16 = createFileRoute("/")({
	head: () => ({
		meta: [
			{ title: "Trans Sahara Consortium — Building Africa's Industrial Backbone" },
			{
				name: "description",
				content: "A diversified industrial group delivering power, oil & gas, agriculture, pipelines, logistics and mining projects across Africa. Headquartered in Abuja, Nigeria."
			},
			{
				property: "og:title",
				content: "Trans Sahara Consortium Limited"
			},
			{
				property: "og:description",
				content: "Integrated industrial solutions across power, energy, agriculture, pipelines, logistics and mining."
			},
			{
				property: "og:url",
				content: "/"
			}
		],
		links: [{
			rel: "canonical",
			href: "/"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$15, "component")
});
var $$splitComponentImporter$14 = () => import("./route-Di7iQBCH.mjs");
var Route$15 = createFileRoute("/_authenticated")({
	ssr: false,
	beforeLoad: async () => {
		const { data, error } = await supabase.auth.getUser();
		if (error || !data.user) throw redirect({ to: "/auth" });
		return { user: data.user };
	},
	component: lazyRouteComponent($$splitComponentImporter$14, "component")
});
var $$splitComponentImporter$13 = () => import("./about-Dk88hlLV.mjs");
var Route$14 = createFileRoute("/about")({
	head: () => ({
		meta: [
			{ title: "About Us — Trans Sahara Consortium" },
			{
				name: "description",
				content: "Trans Sahara Consortium is a Nigerian industrial group delivering power, energy, agriculture, pipelines, logistics and mining projects."
			},
			{
				property: "og:title",
				content: "About Trans Sahara Consortium"
			},
			{
				property: "og:description",
				content: "Our story, our mission and the values that guide our work across Africa."
			},
			{
				property: "og:url",
				content: "/about"
			}
		],
		links: [{
			rel: "canonical",
			href: "/about"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var $$splitComponentImporter$12 = () => import("./auth-q-5ePOQJ.mjs");
var Route$13 = createFileRoute("/auth")({
	head: () => ({ meta: [{ title: "Sign in — Trans Sahara Consortium Admin" }, {
		name: "robots",
		content: "noindex"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
var $$splitComponentImporter$11 = () => import("./contact-CKoc2hDg.mjs");
var Route$12 = createFileRoute("/contact")({
	head: () => ({
		meta: [
			{ title: "Contact Us — Trans Sahara Consortium" },
			{
				name: "description",
				content: "Get in touch with Trans Sahara Consortium Limited at our Abuja headquarters. Phone, email and office address."
			},
			{
				property: "og:title",
				content: "Contact Trans Sahara Consortium"
			},
			{
				property: "og:description",
				content: "8th Floor, Bank of Industry Tower 2, Off Herbert Macaulay Way, Abuja, FCT."
			},
			{
				property: "og:url",
				content: "/contact"
			}
		],
		links: [{
			rel: "canonical",
			href: "/contact"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./gallery-BP4SD3p1.mjs");
var Route$11 = createFileRoute("/gallery")({
	head: () => ({
		meta: [
			{ title: "Gallery — Trans Sahara Consortium" },
			{
				name: "description",
				content: "A visual look at Trans Sahara Consortium's projects across power, oil & gas, agriculture, pipelines, logistics and mining."
			},
			{
				property: "og:title",
				content: "Gallery — Trans Sahara Consortium"
			},
			{
				property: "og:description",
				content: "Projects and operations across Africa."
			},
			{
				property: "og:url",
				content: "/gallery"
			}
		],
		links: [{
			rel: "canonical",
			href: "/gallery"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./services-Cfz2HmEF.mjs");
var Route$10 = createFileRoute("/services")({
	head: () => ({
		meta: [
			{ title: "Our Services — Trans Sahara Consortium" },
			{
				name: "description",
				content: "Integrated industrial services from Trans Sahara Consortium across power, oil & gas, agriculture, pipelines, logistics and mining."
			},
			{
				property: "og:title",
				content: "Services — Trans Sahara Consortium"
			},
			{
				property: "og:description",
				content: "Explore the full range of industrial services offered across our six subsidiaries."
			},
			{
				property: "og:url",
				content: "/services"
			}
		],
		links: [{
			rel: "canonical",
			href: "/services"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var BASE_URL = "";
var Route$9 = createFileRoute("/sitemap.xml")({ server: { handlers: { GET: async () => {
	const xml = [
		`<?xml version="1.0" encoding="UTF-8"?>`,
		`<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">`,
		...[
			"/",
			"/about",
			"/team",
			"/services",
			"/subsidiaries",
			"/gallery",
			"/contact",
			...SUBSIDIARIES.map((s) => `/subsidiaries/${s.slug}`)
		].map((p) => `  <url><loc>${BASE_URL}${p}</loc><changefreq>weekly</changefreq></url>`),
		`</urlset>`
	].join("\n");
	return new Response(xml, { headers: {
		"Content-Type": "application/xml",
		"Cache-Control": "public, max-age=3600"
	} });
} } } });
var $$splitComponentImporter$8 = () => import("./subsidiaries-B_DFyq_H.mjs");
var Route$8 = createFileRoute("/subsidiaries")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./team-X7XSEyuh.mjs");
var Route$7 = createFileRoute("/team")({
	head: () => ({
		meta: [
			{ title: "Our Team — Trans Sahara Consortium" },
			{
				name: "description",
				content: "Meet the executive leadership steering Trans Sahara Consortium Limited across power, energy, agriculture, pipelines, logistics and mining."
			},
			{
				property: "og:title",
				content: "Leadership — Trans Sahara Consortium"
			},
			{
				property: "og:description",
				content: "The executive team behind Trans Sahara Consortium."
			},
			{
				property: "og:url",
				content: "/team"
			}
		],
		links: [{
			rel: "canonical",
			href: "/team"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./route-CT7SZdCp.mjs");
var Route$6 = createFileRoute("/_authenticated/admin")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./subsidiaries.index-Crp1dAFf.mjs");
var Route$5 = createFileRoute("/subsidiaries/")({
	head: () => ({
		meta: [
			{ title: "Subsidiaries — Trans Sahara Consortium" },
			{
				name: "description",
				content: "The six specialized subsidiaries of Trans Sahara Consortium Limited: power, oil & gas, agriculture, pipelines, logistics and mining."
			},
			{
				property: "og:title",
				content: "Our Subsidiaries — Trans Sahara Consortium"
			},
			{
				property: "og:description",
				content: "Meet the six businesses that form Trans Sahara Consortium."
			},
			{
				property: "og:url",
				content: "/subsidiaries"
			}
		],
		links: [{
			rel: "canonical",
			href: "/subsidiaries"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./admin-BkyPCNJu.mjs");
var Route$4 = createFileRoute("/_authenticated/admin/")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./about-S7tuG0Gz.mjs");
var Route$3 = createFileRoute("/_authenticated/admin/about")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./gallery-CSl2VUrX.mjs");
var Route$2 = createFileRoute("/_authenticated/admin/gallery")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./services-BTr3iDnf.mjs");
var Route$1 = createFileRoute("/_authenticated/admin/services")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./team-VwjRRTEe.mjs");
var Route = createFileRoute("/_authenticated/admin/team")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var IndexRoute = Route$16.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$17
});
var AuthenticatedRouteRoute = Route$15.update({
	id: "/_authenticated",
	getParentRoute: () => Route$17
});
var AboutRoute = Route$14.update({
	id: "/about",
	path: "/about",
	getParentRoute: () => Route$17
});
var AuthRoute = Route$13.update({
	id: "/auth",
	path: "/auth",
	getParentRoute: () => Route$17
});
var ContactRoute = Route$12.update({
	id: "/contact",
	path: "/contact",
	getParentRoute: () => Route$17
});
var GalleryRoute = Route$11.update({
	id: "/gallery",
	path: "/gallery",
	getParentRoute: () => Route$17
});
var ServicesRoute = Route$10.update({
	id: "/services",
	path: "/services",
	getParentRoute: () => Route$17
});
var SitemapDotxmlRoute = Route$9.update({
	id: "/sitemap.xml",
	path: "/sitemap.xml",
	getParentRoute: () => Route$17
});
var SubsidiariesRoute = Route$8.update({
	id: "/subsidiaries",
	path: "/subsidiaries",
	getParentRoute: () => Route$17
});
var TeamRoute = Route$7.update({
	id: "/team",
	path: "/team",
	getParentRoute: () => Route$17
});
var AuthenticatedAdminRouteRoute = Route$6.update({
	id: "/admin",
	path: "/admin",
	getParentRoute: () => AuthenticatedRouteRoute
});
var SubsidiariesIndexRoute = Route$5.update({
	id: "/",
	path: "/",
	getParentRoute: () => SubsidiariesRoute
});
var SubsidiariesSlugRoute = Route$18.update({
	id: "/$slug",
	path: "/$slug",
	getParentRoute: () => SubsidiariesRoute
});
var AuthenticatedAdminIndexRoute = Route$4.update({
	id: "/",
	path: "/",
	getParentRoute: () => AuthenticatedAdminRouteRoute
});
var AuthenticatedAdminRouteRouteChildren = {
	AuthenticatedAdminAboutRoute: Route$3.update({
		id: "/about",
		path: "/about",
		getParentRoute: () => AuthenticatedAdminRouteRoute
	}),
	AuthenticatedAdminGalleryRoute: Route$2.update({
		id: "/gallery",
		path: "/gallery",
		getParentRoute: () => AuthenticatedAdminRouteRoute
	}),
	AuthenticatedAdminServicesRoute: Route$1.update({
		id: "/services",
		path: "/services",
		getParentRoute: () => AuthenticatedAdminRouteRoute
	}),
	AuthenticatedAdminTeamRoute: Route.update({
		id: "/team",
		path: "/team",
		getParentRoute: () => AuthenticatedAdminRouteRoute
	}),
	AuthenticatedAdminIndexRoute
};
var AuthenticatedRouteRouteChildren = { AuthenticatedAdminRouteRoute: AuthenticatedAdminRouteRoute._addFileChildren(AuthenticatedAdminRouteRouteChildren) };
var AuthenticatedRouteRouteWithChildren = AuthenticatedRouteRoute._addFileChildren(AuthenticatedRouteRouteChildren);
var SubsidiariesRouteChildren = {
	SubsidiariesSlugRoute,
	SubsidiariesIndexRoute
};
var rootRouteChildren = {
	IndexRoute,
	AuthenticatedRouteRoute: AuthenticatedRouteRouteWithChildren,
	AboutRoute,
	AuthRoute,
	ContactRoute,
	GalleryRoute,
	ServicesRoute,
	SitemapDotxmlRoute,
	SubsidiariesRoute: SubsidiariesRoute._addFileChildren(SubsidiariesRouteChildren),
	TeamRoute
};
var routeTree = Route$17._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	return createRouter({
		routeTree,
		context: { queryClient: new QueryClient() },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
