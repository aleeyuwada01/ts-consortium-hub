import { r as SUBSIDIARIES } from "./site-data-e6ezcBhU.mjs";
import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { r as useGallery } from "./content-hooks-BW9Qg46z.mjs";
import { t as PageHero } from "./PageHero-BTcU8EON.mjs";
import { t as about_office_default } from "./about-office-BV_Sh4pB.mjs";
import { t as hero_sahara_default } from "./hero-sahara-CwOp8IFE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/gallery-BP4SD3p1.js
var import_jsx_runtime = require_jsx_runtime();
function Gallery() {
	const { data = [] } = useGallery();
	const images = data.length ? data.map((g) => ({
		src: g.image_url,
		alt: g.title
	})) : [
		{
			src: hero_sahara_default,
			alt: "Sahara industrial landscape",
			tall: true
		},
		...SUBSIDIARIES.map((s) => ({
			src: s.image,
			alt: s.name
		})),
		{
			src: about_office_default,
			alt: "Corporate headquarters, Abuja"
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
		eyebrow: "Gallery",
		title: "Projects, sites and moments from across the consortium.",
		subtitle: "A visual record of work in progress — from remote field sites in the Sahara belt to the headquarters that coordinates it all."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "section-pad",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "container-page columns-1 sm:columns-2 lg:columns-3 gap-5 [column-fill:_balance]",
			children: images.map((img, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
				className: "mb-5 break-inside-avoid overflow-hidden rounded-2xl border border-border group relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: img.src,
					alt: img.alt,
					loading: "lazy",
					className: `w-full ${img.tall ? "aspect-[3/4]" : "aspect-[4/3]"} object-cover transition-transform duration-700 group-hover:scale-105`
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
					className: "absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 to-transparent p-4 text-sm text-white opacity-0 group-hover:opacity-100 transition-opacity",
					children: img.alt
				})]
			}, i))
		})
	})] });
}
//#endregion
export { Gallery as component };
