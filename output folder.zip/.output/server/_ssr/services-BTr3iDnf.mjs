import { n as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-CqoHPUyh.mjs";
import { a as require_react, i as require_jsx_runtime, r as useQueryClient, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { d as Plus, s as Trash2 } from "../_libs/lucide-react.mjs";
import { t as ImageUploader } from "./ImageUploader-BU2Ti0NX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/services-BTr3iDnf.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function slugify(s) {
	return s.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}
function SubsidiariesAdmin() {
	const qc = useQueryClient();
	const { data = [], isLoading } = useQuery({
		queryKey: ["admin_subsidiaries"],
		queryFn: async () => {
			const { data, error } = await supabase.from("subsidiaries").select("*").order("sort_order");
			if (error) throw error;
			return data ?? [];
		}
	});
	const refresh = () => {
		qc.invalidateQueries({ queryKey: ["admin_subsidiaries"] });
		qc.invalidateQueries({ queryKey: ["subsidiaries"] });
	};
	async function add() {
		const name = prompt("Subsidiary name?");
		if (!name) return;
		const nextOrder = data.length ? Math.max(...data.map((s) => s.sort_order)) + 1 : 1;
		const { error } = await supabase.from("subsidiaries").insert({
			slug: slugify(name),
			name,
			short: name,
			tagline: "",
			description: "",
			capabilities: [],
			sort_order: nextOrder
		});
		if (error) alert(error.message);
		refresh();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-end justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-bold",
				children: "Subsidiaries & Services"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "These entries power both the Services page and the Subsidiaries dropdown."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: add,
				className: "btn-primary",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add"]
			})]
		}), isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted-foreground",
			children: "Loading…"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-4",
			children: data.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubRow, {
				sub: s,
				onChanged: refresh
			}, s.id))
		})]
	});
}
function SubRow({ sub, onChanged }) {
	const [s, setS] = (0, import_react.useState)(sub);
	const [caps, setCaps] = (0, import_react.useState)(sub.capabilities.join("\n"));
	const [saving, setSaving] = (0, import_react.useState)(false);
	async function save() {
		setSaving(true);
		const { error } = await supabase.from("subsidiaries").update({
			slug: s.slug,
			name: s.name,
			short: s.short,
			tagline: s.tagline,
			description: s.description,
			capabilities: caps.split("\n").map((c) => c.trim()).filter(Boolean),
			image_url: s.image_url,
			sort_order: s.sort_order
		}).eq("id", s.id);
		setSaving(false);
		if (error) alert(error.message);
		onChanged();
	}
	async function remove() {
		if (!confirm(`Delete "${s.name}"?`)) return;
		const { error } = await supabase.from("subsidiaries").delete().eq("id", s.id);
		if (error) alert(error.message);
		onChanged();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
		className: "rounded-2xl border border-border bg-card p-5 group",
		open: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
			className: "cursor-pointer flex items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "font-bold",
				children: s.short || s.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-xs text-muted-foreground font-mono",
				children: ["/", s.slug]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: s.name,
							onChange: (e) => setS({
								...s,
								name: e.target.value
							}),
							placeholder: "Full name",
							className: "rounded-lg border border-input bg-background px-3 py-2 text-sm"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: s.short,
							onChange: (e) => setS({
								...s,
								short: e.target.value
							}),
							placeholder: "Short name",
							className: "rounded-lg border border-input bg-background px-3 py-2 text-sm"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: s.slug,
							onChange: (e) => setS({
								...s,
								slug: slugify(e.target.value)
							}),
							placeholder: "URL slug",
							className: "rounded-lg border border-input bg-background px-3 py-2 text-sm font-mono"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "number",
							value: s.sort_order,
							onChange: (e) => setS({
								...s,
								sort_order: Number(e.target.value)
							}),
							placeholder: "Sort order",
							className: "rounded-lg border border-input bg-background px-3 py-2 text-sm"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: s.tagline,
					onChange: (e) => setS({
						...s,
						tagline: e.target.value
					}),
					placeholder: "Tagline",
					className: "rounded-lg border border-input bg-background px-3 py-2 text-sm"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					rows: 4,
					value: s.description,
					onChange: (e) => setS({
						...s,
						description: e.target.value
					}),
					placeholder: "Description",
					className: "rounded-lg border border-input bg-background px-3 py-2 text-sm"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-sm font-medium",
					children: "Capabilities (one per line)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					rows: 5,
					value: caps,
					onChange: (e) => setCaps(e.target.value),
					className: "mt-1 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm font-mono"
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageUploader, {
					value: s.image_url,
					onChange: (u) => setS({
						...s,
						image_url: u
					}),
					folder: "subsidiaries",
					label: "Hero image"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: save,
						disabled: saving,
						className: "btn-primary",
						children: saving ? "Saving…" : "Save"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: remove,
						className: "btn-outline text-brand-red",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" }), " Delete"]
					})]
				})
			]
		})]
	});
}
//#endregion
export { SubsidiariesAdmin as component };
