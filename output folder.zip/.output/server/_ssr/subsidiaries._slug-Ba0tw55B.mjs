import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { i as useSubsidiaries } from "./content-hooks-BW9Qg46z.mjs";
import { D as CircleCheck, M as ArrowLeft, j as ArrowRight } from "../_libs/lucide-react.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Route } from "./subsidiaries._slug-CBEfxGNK.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/subsidiaries._slug-Ba0tw55B.js
var import_jsx_runtime = require_jsx_runtime();
function Detail() {
	const { item: loaderItem } = Route.useLoaderData();
	const { data: subs = [] } = useSubsidiaries();
	const item = subs.find((s) => s.slug === loaderItem.slug) ?? loaderItem;
	const idx = subs.findIndex((s) => s.slug === item.slug);
	const next = subs[((idx < 0 ? 0 : idx) + 1) % (subs.length || 1)] ?? item;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative overflow-hidden ink-gradient text-white",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: item.image,
					alt: "",
					className: "absolute inset-0 h-full w-full object-cover opacity-30",
					width: 1200,
					height: 800
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-r from-black/85 via-black/60 to-transparent" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "container-page relative py-24 md:py-36",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/subsidiaries",
							className: "inline-flex items-center gap-2 text-white/70 hover:text-white text-sm mb-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), " All subsidiaries"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "eyebrow text-brand-green",
							children: [
								"Subsidiary 0",
								idx + 1,
								" / 06"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-4 text-4xl md:text-6xl font-bold max-w-3xl leading-[1.05]",
							children: item.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-xl text-brand-green max-w-2xl",
							children: item.tagline
						})
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "section-pad",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-page grid gap-16 lg:grid-cols-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-7",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "eyebrow",
							children: "Overview"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 text-3xl md:text-4xl font-bold",
							children: "A focused business, backed by a consortium."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-lg text-muted-foreground leading-relaxed",
							children: item.description
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-4 text-lg text-muted-foreground leading-relaxed",
							children: [
								"As part of Trans Sahara Consortium, ",
								item.short,
								" draws on shared group resources — engineering talent, project finance, HSE governance and logistics — to deliver at a scale few standalone operators can match."
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "lg:col-span-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-3xl bg-secondary/60 border border-border p-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "eyebrow",
							children: "Core capabilities"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-5 space-y-3",
							children: item.capabilities.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-3 items-start",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-5 w-5 text-brand-green-deep shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: c
								})]
							}, c))
						})]
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "pb-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "container-page",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/subsidiaries/$slug",
					params: { slug: next.slug },
					className: "group flex flex-wrap items-center justify-between gap-6 rounded-3xl bg-card border border-border p-8 hover:border-brand-green/50 transition-all",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs uppercase tracking-widest text-muted-foreground",
						children: "Next subsidiary"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 text-2xl font-bold",
						children: next.short
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-6 w-6 text-brand-green-deep transition-transform group-hover:translate-x-1" })]
				})
			})
		})
	] });
}
//#endregion
export { Detail as component };
