import { n as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-CqoHPUyh.mjs";
import { a as require_react, i as require_jsx_runtime, r as useQueryClient } from "../_libs/react+tanstack__react-query.mjs";
import { n as useAbout } from "./content-hooks-BW9Qg46z.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-S7tuG0Gz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AboutAdmin() {
	const { data } = useAbout();
	const qc = useQueryClient();
	const [form, setForm] = (0, import_react.useState)(null);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [msg, setMsg] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (data && !form) setForm(data);
	}, [data, form]);
	if (!form) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted-foreground",
		children: "Loading…"
	});
	async function save() {
		if (!form) return;
		setSaving(true);
		setMsg(null);
		const { error } = await supabase.from("about_content").update({
			hero_eyebrow: form.hero_eyebrow,
			hero_title: form.hero_title,
			hero_subtitle: form.hero_subtitle,
			story_heading: form.story_heading,
			story_body: form.story_body,
			mission: form.mission,
			vision: form.vision
		}).eq("id", 1);
		setSaving(false);
		if (error) setMsg(error.message);
		else {
			setMsg("Saved.");
			qc.invalidateQueries({ queryKey: ["about_content"] });
		}
	}
	const F = ({ label, k, textarea }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: "text-sm font-medium",
		children: label
	}), textarea ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		rows: 5,
		value: String(form[k] ?? ""),
		onChange: (e) => setForm({
			...form,
			[k]: e.target.value
		}),
		className: "mt-1 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm"
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		value: String(form[k] ?? ""),
		onChange: (e) => setForm({
			...form,
			[k]: e.target.value
		}),
		className: "mt-1 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm"
	})] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-2xl font-bold",
			children: "About page"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "Editable copy on the public /about page."
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-2xl border border-border bg-card p-6 space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
					label: "Hero eyebrow",
					k: "hero_eyebrow"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
					label: "Hero title",
					k: "hero_title"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
					label: "Hero subtitle",
					k: "hero_subtitle",
					textarea: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
					label: "Story heading",
					k: "story_heading"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
					label: "Story body",
					k: "story_body",
					textarea: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
					label: "Mission statement",
					k: "mission",
					textarea: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
					label: "Vision statement",
					k: "vision",
					textarea: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: save,
						disabled: saving,
						className: "btn-primary",
						children: saving ? "Saving…" : "Save changes"
					}), msg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-muted-foreground",
						children: msg
					})]
				})
			]
		})]
	});
}
//#endregion
export { AboutAdmin as component };
