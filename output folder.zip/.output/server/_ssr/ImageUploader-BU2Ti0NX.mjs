import { n as __toESM } from "../_runtime.mjs";
import { a as require_react, i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as uploadSiteImage } from "./content-hooks-BW9Qg46z.mjs";
import { a as Upload, n as X } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ImageUploader-BU2Ti0NX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ImageUploader({ value, onChange, folder, label = "Image" }) {
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [err, setErr] = (0, import_react.useState)(null);
	async function onFile(e) {
		const file = e.target.files?.[0];
		if (!file) return;
		setErr(null);
		setBusy(true);
		try {
			onChange(await uploadSiteImage(file, folder));
		} catch (e) {
			setErr(e instanceof Error ? e.message : "Upload failed");
		} finally {
			setBusy(false);
			e.target.value = "";
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
			className: "text-sm font-medium",
			children: label
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-1 flex items-start gap-3",
			children: [value ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: value,
					alt: "",
					className: "h-24 w-32 rounded-lg object-cover border border-border"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onChange(null),
					className: "absolute -top-2 -right-2 h-6 w-6 rounded-full bg-brand-ink text-white flex items-center justify-center",
					"aria-label": "Remove image",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-3.5 w-3.5" })
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-24 w-32 rounded-lg border border-dashed border-border flex items-center justify-center text-xs text-muted-foreground",
				children: "No image"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "btn-outline cursor-pointer inline-flex text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "h-4 w-4" }),
					busy ? "Uploading…" : "Upload",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "file",
						accept: "image/*",
						className: "hidden",
						onChange: onFile,
						disabled: busy
					})
				]
			})]
		}),
		err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-xs text-brand-red",
			children: err
		})
	] });
}
//#endregion
export { ImageUploader as t };
