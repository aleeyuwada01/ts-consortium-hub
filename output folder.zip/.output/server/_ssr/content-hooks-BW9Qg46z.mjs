import { r as SUBSIDIARIES } from "./site-data-e6ezcBhU.mjs";
import { t as supabase } from "./client-CqoHPUyh.mjs";
import { t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/content-hooks-BW9Qg46z.js
var STATIC_BY_SLUG = new Map(SUBSIDIARIES.map((s) => [s.slug, s]));
function useSubsidiaries() {
	return useQuery({
		queryKey: ["subsidiaries"],
		queryFn: async () => {
			const { data, error } = await supabase.from("subsidiaries").select("*").order("sort_order");
			if (error) throw error;
			if (!data || data.length === 0) return SUBSIDIARIES;
			return data.map((row) => {
				const fallback = STATIC_BY_SLUG.get(row.slug);
				return {
					id: row.id,
					slug: row.slug,
					name: row.name,
					short: row.short,
					tagline: row.tagline,
					description: row.description,
					capabilities: row.capabilities ?? [],
					image: row.image_url || fallback?.image || "",
					image_url: row.image_url
				};
			});
		},
		initialData: SUBSIDIARIES,
		staleTime: 3e4
	});
}
function useAbout() {
	return useQuery({
		queryKey: ["about_content"],
		queryFn: async () => {
			const { data, error } = await supabase.from("about_content").select("*").eq("id", 1).maybeSingle();
			if (error) throw error;
			return data;
		},
		staleTime: 3e4
	});
}
function useTeam() {
	return useQuery({
		queryKey: ["team_members"],
		queryFn: async () => {
			const { data, error } = await supabase.from("team_members").select("*").order("sort_order");
			if (error) throw error;
			return data ?? [];
		},
		staleTime: 3e4
	});
}
function useGallery() {
	return useQuery({
		queryKey: ["gallery_images"],
		queryFn: async () => {
			const { data, error } = await supabase.from("gallery_images").select("*").order("sort_order");
			if (error) throw error;
			return data ?? [];
		},
		staleTime: 3e4
	});
}
/** Upload a file to site-images and return a very-long-lived signed URL. */
async function uploadSiteImage(file, folder) {
	const ext = file.name.split(".").pop() || "jpg";
	const path = `${folder}/${crypto.randomUUID()}.${ext}`;
	const { error: upErr } = await supabase.storage.from("site-images").upload(path, file, {
		cacheControl: "31536000",
		upsert: false,
		contentType: file.type
	});
	if (upErr) throw upErr;
	const { data, error } = await supabase.storage.from("site-images").createSignedUrl(path, 3600 * 24 * 365 * 100);
	if (error || !data?.signedUrl) throw error ?? /* @__PURE__ */ new Error("Failed to sign URL");
	return data.signedUrl;
}
//#endregion
export { useTeam as a, useSubsidiaries as i, useAbout as n, useGallery as r, uploadSiteImage as t };
