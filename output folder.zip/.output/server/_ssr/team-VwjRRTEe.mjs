import { n as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-CqoHPUyh.mjs";
import { a as require_react, i as require_jsx_runtime, r as useQueryClient } from "../_libs/react+tanstack__react-query.mjs";
import { a as useTeam } from "./content-hooks-BW9Qg46z.mjs";
import { d as Plus, s as Trash2 } from "../_libs/lucide-react.mjs";
import { t as ImageUploader } from "./ImageUploader-BU2Ti0NX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/team-VwjRRTEe.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TeamAdmin() {
	const { data = [], isLoading } = useTeam();
	const qc = useQueryClient();
	const refresh = () => qc.invalidateQueries({ queryKey: ["team_members"] });
	async function addMember() {
		const nextOrder = data.length ? Math.max(...data.map((m) => m.sort_order)) + 1 : 1;
		const { error } = await supabase.from("team_members").insert({
			name: "New member",
			role: "Role",
			sort_order: nextOrder
		});
		if (error) alert(error.message);
		refresh();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-end justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-bold",
				children: "Team members"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Manage the leadership shown on /team."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: addMember,
				className: "btn-primary",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add"]
			})]
		}), isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted-foreground",
			children: "Loading…"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-4",
			children: data.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MemberRow, {
				member: m,
				onChanged: refresh
			}, m.id))
		})]
	});
}
function MemberRow({ member, onChanged }) {
	const [m, setM] = (0, import_react.useState)(member);
	const [saving, setSaving] = (0, import_react.useState)(false);
	async function save() {
		setSaving(true);
		const { error } = await supabase.from("team_members").update({
			name: m.name,
			role: m.role,
			image_url: m.image_url,
			linkedin_url: m.linkedin_url,
			email: m.email,
			sort_order: m.sort_order
		}).eq("id", m.id);
		setSaving(false);
		if (error) alert(error.message);
		onChanged();
	}
	async function remove() {
		if (!confirm(`Delete ${m.name}?`)) return;
		const { error } = await supabase.from("team_members").delete().eq("id", m.id);
		if (error) alert(error.message);
		onChanged();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-border bg-card p-5 grid gap-4 md:grid-cols-[auto_1fr_auto] items-start",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageUploader, {
				value: m.image_url,
				onChange: (u) => setM({
					...m,
					image_url: u
				}),
				folder: "team",
				label: "Photo"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: m.name,
						onChange: (e) => setM({
							...m,
							name: e.target.value
						}),
						placeholder: "Name",
						className: "rounded-lg border border-input bg-background px-3 py-2 text-sm"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: m.role,
						onChange: (e) => setM({
							...m,
							role: e.target.value
						}),
						placeholder: "Role",
						className: "rounded-lg border border-input bg-background px-3 py-2 text-sm"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: m.linkedin_url ?? "",
						onChange: (e) => setM({
							...m,
							linkedin_url: e.target.value || null
						}),
						placeholder: "LinkedIn URL",
						className: "rounded-lg border border-input bg-background px-3 py-2 text-sm"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: m.email ?? "",
						onChange: (e) => setM({
							...m,
							email: e.target.value || null
						}),
						placeholder: "Email",
						className: "rounded-lg border border-input bg-background px-3 py-2 text-sm"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						value: m.sort_order,
						onChange: (e) => setM({
							...m,
							sort_order: Number(e.target.value)
						}),
						placeholder: "Sort order",
						className: "rounded-lg border border-input bg-background px-3 py-2 text-sm"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: save,
					disabled: saving,
					className: "btn-primary text-sm",
					children: saving ? "…" : "Save"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: remove,
					className: "btn-outline text-sm text-brand-red",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" }), " Delete"]
				})]
			})
		]
	});
}
//#endregion
export { TeamAdmin as component };
