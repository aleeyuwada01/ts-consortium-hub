import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { b as Image, i as Users, k as Briefcase, w as FileText } from "../_libs/lucide-react.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-BkyPCNJu.js
var import_jsx_runtime = require_jsx_runtime();
var CARDS = [
	{
		to: "/admin/about",
		label: "About page",
		desc: "Hero, story, mission and vision text.",
		icon: FileText
	},
	{
		to: "/admin/team",
		label: "Team members",
		desc: "Executive leadership entries and photos.",
		icon: Users
	},
	{
		to: "/admin/services",
		label: "Subsidiaries & Services",
		desc: "Six business units, taglines, capabilities, images.",
		icon: Briefcase
	},
	{
		to: "/admin/gallery",
		label: "Gallery",
		desc: "Photos shown on the public gallery page.",
		icon: Image
	}
];
function AdminHome() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-3xl font-bold",
			children: "Content admin"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-muted-foreground",
			children: "Edit any section below. Changes go live immediately — no redeploy required."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-8 grid gap-4 sm:grid-cols-2",
			children: CARDS.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: c.to,
				className: "group rounded-2xl border border-border bg-card p-6 hover:border-brand-green/50 transition-all hover:-translate-y-0.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(c.icon, { className: "h-6 w-6 text-brand-green-deep" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-4 text-lg font-bold",
						children: c.label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: c.desc
					})
				]
			}, c.to))
		})
	] });
}
//#endregion
export { AdminHome as component };
